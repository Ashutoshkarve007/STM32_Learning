#include "StringUtilities.h"
#include "UART.h"

void DisplayHeader();
void DisplayAxisValues();