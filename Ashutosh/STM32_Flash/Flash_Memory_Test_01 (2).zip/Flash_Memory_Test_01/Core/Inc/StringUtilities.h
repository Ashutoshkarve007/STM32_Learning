// Simply converts an integer value to a string.  This code came from
// https://stackoverflow.com/questions/8257714/how-to-convert-an-int-to-string-in-c
#pragma once

#define BASE_10  10

char* IntegerToString(int value, char *result, int base);